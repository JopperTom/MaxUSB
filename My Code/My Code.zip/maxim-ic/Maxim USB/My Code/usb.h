#ifndef USB_H
#define USB_H

BYTE Check_INT(void);

void StallEP0(void);


void Bus_Reset(void);
void Bus_Resume(void);
void Reset_MAX(int);


BYTE Wait_for_HIRQ(BYTE regbit);


void Ack_Status(void);
BYTE readstat(void);

void wregAS16(BYTE reg,BYTE dat);
void std_request(void);
void class_request(void);
void vendor_request(void);
void send_descriptor(void);


// Host-specific
BYTE check_HRSL(void);
BYTE CTL_WRITE(void);
BYTE CTL_READ(void);
void waitframes(int num);
BYTE Set_Address(BYTE addr);
BYTE Get_Device_Status(void);
BYTE H_GetStat(BYTE port);
BYTE HubPort_Feature(BYTE setnotclr,BYTE feat,BYTE port);
BYTE Set_Idle(BYTE iface, BYTE duration, BYTE reportID);
BYTE Set_Config(BYTE cfgval);
BYTE Get_Descriptor(BYTE type,WORD length);

// SPI_x.C prototypes
void set_addr(void);
void send_keystroke(BYTE);
void feature(BYTE);
void get_status(void);
void set_interface(void);
void get_interface(void);
void set_configuration(void);
void get_configuration(void);

BYTE H_D_GetStat(void);


#endif
