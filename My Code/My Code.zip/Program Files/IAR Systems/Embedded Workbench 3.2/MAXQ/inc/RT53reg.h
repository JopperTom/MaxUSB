#ifndef RT53REG_H
#define RT53REG_H

#include <iomaxq200x.h>

//__no_init volatile __io unsigned short CKCN @ _M(8,0xE);  /* System Clock Control */ 
//__no_init volatile __io unsigned short IMR @ _M(8,0x6);   /* Interrupt Mask Register */ 

typedef unsigned char BYTE;
typedef unsigned short WORD;

void timeDELAY(long int x){long int y; for( y=0; y<x ; y++);}

//These are deficed in interface.c
//#define CS_HI PO5 |= 0x10;          // Macros to set the MAXQ2000 SPI CS signal (PO5) high and low
//#define CS_LO PO5 &= ~0x10;


// Host XFR token values. Or this bit field with the endpoint number (bits 3:0)
#define tokSETUP 0x10
#define tokIN 0x00
#define tokOUT 0x20
#define tokINHS 0x80
#define tokOUTHS 0xC0
#define tokISOIN 0x40
#define tokISOOUT 0x60

// Host error result codes
#define hrSUCCESS   0x00
#define hrBUSY      0x01
#define hrBADREQ    0x02
#define hrUNDEF     0x03
#define hrNAK       0x04
#define hrSTALL     0x05
#define hrTOGERR    0x06
#define hrWRONGPID  0x07
#define hrBADBC     0x08
#define hrPIDERR    0x09
#define hrPKTERR    0x0A
#define hrCRCERR    0x0B
#define hrKERR      0x0C
#define hrJERR      0x0D
#define hrTIMEOUT   0x0E
#define hrBABBLE    0x0F


// Macros
// Lights attached to MAX3410E GP-Output pins ACTIVE LOW
/*
#define L1_ON wreg(rGPIO,(rreg(rGPIO) & 0xFE));
#define L1_OFF wreg(rGPIO,(rreg(rGPIO) | 0x01));
#define L2_ON wreg(rGPIO,(rreg(rGPIO) & 0xFD));
#define L2_OFF wreg(rGPIO,(rreg(rGPIO) | 0x02));
#define L3_ON wreg(rGPIO,(rreg(rGPIO) & 0xFB));
#define L3_OFF wreg(rGPIO,(rreg(rGPIO) | 0x04));
#define L4_ON wreg(rGPIO,(rreg(rGPIO) & 0xF7));
#define L4_OFF wreg(rGPIO,(rreg(rGPIO) | 0x08));
#define L1_BLINK wreg(rGPIO,(rreg(rGPIO) ^ 0x01));
#define L2_BLINK wreg(rGPIO,(rreg(rGPIO) ^ 0x02));
#define L3_BLINK wreg(rGPIO,(rreg(rGPIO) ^ 0x04));
#define L4_BLINK wreg(rGPIO,(rreg(rGPIO) ^ 0x08));
*/
// Lights attached to MAX3410E GP-Output pins ACTIVE HIGH
#define L1_OFF wreg(rGPIO,(rreg(rGPIO) & 0xFE));
#define L1_ON wreg(rGPIO,(rreg(rGPIO) | 0x01));
#define L2_OFF wreg(rGPIO,(rreg(rGPIO) & 0xFD));
#define L2_ON wreg(rGPIO,(rreg(rGPIO) | 0x02));
#define L3_OFF wreg(rGPIO,(rreg(rGPIO) & 0xFB));
#define L3_ON wreg(rGPIO,(rreg(rGPIO) | 0x04));
#define L4_OFF wreg(rGPIO,(rreg(rGPIO) & 0xF7));
#define L4_ON wreg(rGPIO,(rreg(rGPIO) | 0x08));
#define L1_BLINK wreg(rGPIO,(rreg(rGPIO) ^ 0x01));
#define L2_BLINK wreg(rGPIO,(rreg(rGPIO) ^ 0x02));
#define L3_BLINK wreg(rGPIO,(rreg(rGPIO) ^ 0x04));
#define L4_BLINK wreg(rGPIO,(rreg(rGPIO) ^ 0x08));


// now for RT53
#define L5_OFF wreg(rIOPINS2,(rreg(rIOPINS2) & 0xFE));
#define L5_ON wreg(rIOPINS2,(rreg(rIOPINS2) | 0x01));
#define L6_OFF wreg(rIOPINS2,(rreg(rIOPINS2) & 0xFD));
#define L6_ON wreg(rIOPINS2,(rreg(rIOPINS2) | 0x02));
#define L7_OFF wreg(rIOPINS2,(rreg(rIOPINS2) & 0xFB));
#define L7_ON wreg(rIOPINS2,(rreg(rIOPINS2) | 0x04));
#define L8_OFF wreg(rIOPINS2,(rreg(rIOPINS2) & 0xF7));
#define L8_ON wreg(rIOPINS2,(rreg(rIOPINS2) | 0x08));
#define L5_BLINK wreg(rIOPINS2,(rreg(rIOPINS2) ^ 0x01));
#define L6_BLINK wreg(rIOPINS2,(rreg(rIOPINS2) ^ 0x02));
#define L7_BLINK wreg(rIOPINS2,(rreg(rIOPINS2) ^ 0x04));
#define L8_BLINK wreg(rIOPINS2O,(rreg(rIOPINS2) ^ 0x08));
// Bargraph lights on the MAXQ2000 board
#define B1ON PO0|=0x80;
#define B1OFF PO0 &= ~0x80;
#define B2ON PO0|=0x40;
#define B3ON PO0|=0x20;
#define B4ON PO0|=0x10;
#define B5ON PO0|=0x08;
#define B6ON PO0|=0x04;
#define B7ON PO0|=0x02;
#define B8ON PO0|=0x01;
//
#define SUSPEND_INT_ON wreg(rUSBIEN,(rreg(rUSBIEN) | bmSUSPEND));
#define SUSPEND_INT_OFF wreg(rUSBIEN,(rreg(rUSBIEN) & !bmSUSPEND));
#define BUSACT_INT_ON wreg(rUSBIEN,(rreg(rUSBIEN) | bmBUSACT));
#define BUSACT_INT_OFF wreg(rUSBIEN,(rreg(rUSBIEN) & !bmBUSACT));
#define SETBIT(reg,val) wreg(reg,(rreg(reg)|val));
#define CLRBIT(reg,val) wreg(reg,(rreg(reg)&~val));
//
#define STALL_EP0 wreg(9,0x23);	// Set all three EP0 stall bits--data stage IN/OUT and status stage

// Registers
#define rEP0FIFO 0
#define rEP1OUTFIFO	1
#define rEP2INFIFO 2
#define rEP3INFIFO 3
#define rSUDFIFO 4
#define rEP0BC 5
#define rEP1OUTBC 6
#define rEP2INBC 7
#define rEP3INBC 8
#define rEPSTALLS 9
#define rCLRTOGS 10
#define rEPIRQ 11
#define rEPIEN 12
#define rUSBIRQ 13
#define rUSBIEN 14
#define rUSBCTL 15
#define rCPUCTL 16
#define rPINCTL 17
#define rRevision 18
#define rFNADDR	19
#define rGPIO 20
// added RT53 regs
#define rIOPINS1 20     // alias for previous definition
#define rIOPINS2 21
#define rGPINIRQ 22
#define rGPINIEN 23
#define rGPINPOL 24
#define rHIRQ 25
#define rHIEN 26
#define rMODE 27
#define rPERADDR 28
#define rHCTL 29
#define rHXFR 30
#define rHRSL 31

// Constants
// PINCTL Register
#define bmFDUPSPI 0x10
#define bmINTLEVEL 0x08
#define bmPOSINT 0x04
#define bmGPOB 0x02
#define	bmGPOA 0x01
// USBCTL Register
#define bmHOSCSTEN 0x80
#define bmVBGATE 0x40
#define bmCHIPRES 0x20
#define bmPWRDOWN 0x10
#define bmCONNECT 0x08
#define bmSIGRWU 0x04
// R11 EPIRQ register bits
#define bmSUDAVIRQ 0x20
#define bmIN3BAVIRQ 0x10
#define bmIN2BAVIRQ 0x08
#define bmOUT1DAVIRQ 0x04
#define bmOUT0DAVIRQ 0x02
#define bmIN0BAVIRQ 0x01
// R12 EPIEN register bits
#define bmSUDAVIE 0x20
#define bmIN3BAVIE 0x10
#define bmIN2BAVIE 0x08
#define bmOUT1DAVIE 0x04
#define bmOUT0DAVIE 0x02
#define bmIN0BAVIE 0x01
// R13 USBIRQ register bits
#define bmURESDNIRQ 0x80
#define bmVBUSIRQ 0x40
#define bmNOVBUSIRQ 0x20
#define bmSUSPIRQ 0x10
#define bmURESIRQ 0x08
#define bmBUSACTIRQ 0x04
#define bmRWUDNIRQ 0x02
#define bmOSCOKIRQ 0x01
// R14 USBIEN register bits
#define bmURESDNIE 0x80
#define bmVBUSIE 0x40
#define bmNOVBUSIE 0x20
#define bmSUSPIE 0x10
#define bmURESIE 0x08
#define bmBUSACTIE 0x04
#define bmRWUDNIE 0x02
#define bmOSCOKIE 0x01
// R9 EPSTALLS register bits
#define bmACKSTAT 0x40
#define bmCTLSTAT 0x20
#define bmEP3IN 0x10
#define bmEP2IN 0x08
#define bmEP1OUT 0x04
#define bmEP0OUT 0x02
#define bmEP0IN 0x01
// R16 CPUCTL bits
#define bmIE 0x01
#define bmPULSEWID1 0x80    // added with chip rev 0x12
#define bmPULSEWID0 0x40    // ditto

// New bits for RT53
// renamed registers
#define rRCVFIFO  0x01
#define rSNDFIFO  0x02
#define rRCVBC 0x06
#define rSNDBC 0x07
// R21--IOPINS2
#define bmGPOUT4 0x01
#define bmGPOUT5 0x02
#define bmGPOUT6 0x04
#define bmGPOUT7 0x08
#define bmGPIN4  0x10
#define bmGPIN5  0x20
#define bmGPIN6  0x40
#define bmGPIN7  0x80
// R22--GPINIRQ
#define bmGPINIRQ0 0x01
#define bmGPINIRQ1 0x02
#define bmGPINIRQ2 0x04
#define bmGPINIRQ3 0x08
#define bmGPINIRQ4 0x10
#define bmGPINIRQ5 0x20
#define bmGPINIRQ6 0x40
#define bmGPINIRQ7 0x80
// R23--GPINIEN
#define bmGPINIEN0 0x01
#define bmGPINIEN1 0x02
#define bmGPINIEN2 0x04
#define bmGPINIEN3 0x08
#define bmGPINIEN4 0x10
#define bmGPINIEN5 0x20
#define bmGPINIEN6 0x40
#define bmGPINIEN7 0x80
// R24--GPINPOL
#define bmGPINPOL0 0x01
#define bmGPINPOL1 0x02
#define bmGPINPOL2 0x04
#define bmGPINPOL3 0x08
#define bmGPINPOL4 0x10
#define bmGPINPOL5 0x20
#define bmGPINPOL6 0x40
#define bmGPINPOL7 0x80
// R25--HIRQ
//#define bmBUSRSTDNIRQ 0x01
#define bmBUSEVENTIRQ 0x01        // modified 4-25-05 to also use for BUSRSM operation
#define bmRSMREQDETIRQ 0x02
#define bmRCVDAVIRQ 0x04
#define bmSNDBAVIRQ 0x08
#define bmSUSPENDDNIRQ 0x10
#define bmCONNIRQ 0x20
#define bmFRAMEIRQ 0x40
#define bmHXFRDNIRQ 0x80
//R26--HIEN
//#define bmBUSRSTDNIE 0x01
#define bmBUSEVENTIE 0x01        // modified 4-25-05 to also use for BUSRSM operation
#define bmRSMREQDETIEQ 0x02
#define bmRCVDAVIE 0x04
#define bmSNDBAVIE 0x08
#define bmSUSPENDDNIE 0x10
#define bmCONNIE 0x20
#define bmFRAMEIE 0x40
#define bmHXFRDNIE 0x80
// R27--MODE
#define bmHOST 0x01
#define bmLOWSPEED 0x02
#define bmHUBPRE 0x04
#define bmSOFKAENAB 0x08
#define bmSEPIRQ 0x10
// 0
#define bmDMPULLDN 0x40
#define bmDPPULLDN 0x80
// R28--PERADDR     // don't need to access bits
// R29--HCTL
#define bmBUSRST 0x01
#define bmFRMRST 0x02
#define bmSAMPLEBUS 0x04
// 0
#define bmBUSRSM 0x08   // added 4-25-05
#define bmRCVTOG0 0x10
#define bmRCVTOG1 0x20
#define bmSNDTOG0 0x40
#define bmSNDTOG1 0x80
// R30--HXFR
// bits 0-3 are ep number, don't need bit names (masks)
#define bmSETUP 0x10
#define bmOUTNIN 0x20  // Rev 0x12 change (added ISO)
//#define bmXOUT 0x40
#define bmISO 0x40      // Rev 0x12 change (added ISO)
#define bmHS 0x80
// R31--HRSL
#define bmHRSLT0 0x01
#define bmHRSLT1 0x02
#define bmHRSLT2 0x04
#define bmHRSLT3 0x08
#define bmRCVTOGRD 0x10
#define bmSNDTOGRD 0x20
#define bmKSTATUS 0x40
#define bmJSTATUS 0x80

// SPI status byte bits
#define stSUSPEND 0x80
#define stUSBRES 0x40
#define stSUDAV 0x20
#define stIN3BAV 0x10
#define stIN2BAV 0x08
#define stOUT1DAV 0x04
#define stOUT0DAV 0x02
#define stIN0BAV 0x01

// Standard Requests
#define SR_GET_STATUS			0x00	// Setup command: Get Status
#define SR_CLEAR_FEATURE		0x01	// Setup command: Clear Feature
#define SR_RESERVED				0x02	// Setup command: Reserved
#define SR_SET_FEATURE			0x03	// Setup command: Set Feature
#define SR_SET_ADDRESS			0x05	// Setup command: Set Address
#define SR_GET_DESCRIPTOR		0x06	// Setup command: Get Descriptor
#define SR_SET_DESCRIPTOR		0x07	// Setup command: Set Descriptor
#define SR_GET_CONFIGURATION	0x08	// Setup command: Get Configuration
#define SR_SET_CONFIGURATION	0x09	// Setup command: Set Configuration
#define SR_GET_INTERFACE		0x0a	// Setup command: Get Interface
#define SR_SET_INTERFACE		0x0b	// Setup command: Set Interface
// Get Descriptor codes	
#define GD_DEVICE				0x01	// Get device descriptor: Device
#define GD_CONFIGURATION		0x02	// Get device descriptor: Configuration
#define GD_STRING				0x03	// Get device descriptor: String
#define GD_HID	            	0x21	// Get descriptor: HID
#define GD_REPORT	         	0x22	// Get descriptor: Report
// SETUP packet offsets
#define bmRequestType	0
#define	bRequest		1
#define wValueL			2
#define wValueH			3
#define wIndexL			4
#define wIndexH			5
#define wLengthL		6
#define wLengthH		7
// HID bRequest values
#define GET_REPORT		1
#define GET_IDLE		2
#define GET_PROTOCOL	3
#define SET_REPORT		9
#define SET_IDLE		0x0A
#define SET_PROTOCOL	0x0B
#define INPUT_REPORT	1
//
#endif


